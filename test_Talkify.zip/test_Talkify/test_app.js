/**
 * 
 */
var express = require("express"),
    path = require("path"),
    http = require("http"),
    PORT = 3034,
    app = express();

//all environments
express.static.mime.default_type = "text/xml";
app.use(express.static(path.join(__dirname, 'public')));

var process = require("./processUsrText.js");

app.get('/process/:usrmsg', function(req, res){
	var resp = process.processMsg(req.params.usrmsg);
	res.send(resp);
});

//start http server
app.listen(PORT, function(){
  console.log('HTTP Server: http://localhost:' + PORT);
});