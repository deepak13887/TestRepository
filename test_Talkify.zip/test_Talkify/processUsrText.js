
// Core dependency 
const talkify = require('talkify');
const Bot = talkify.Bot;
 
// Types dependencies 
const BotTypes = talkify.BotTypes;
const Message = BotTypes.Message;
const SingleLineMessage = BotTypes.SingleLineMessage;
const MultiLineMessage = BotTypes.MultiLineMessage;
 
// Skills dependencies 
const Skill = BotTypes.Skill;
 
// Training dependencies 
const TrainingDocument = BotTypes.TrainingDocument;

const bot = new Bot();
bot.trainAll([
              //Generic queries              
              new TrainingDocument('how_are_you', 'how are you'),
              new TrainingDocument('how_are_you', 'what are you doing'),
              
              new TrainingDocument('who_are_you', 'who are you'),
              new TrainingDocument('who_are_you', 'what is your name'),
              new TrainingDocument('who_are_you', 'identify yourself'),
           
              new TrainingDocument('help', 'i need some help'),
              new TrainingDocument('help', 'can you assist me'),
              
              new TrainingDocument('hi', 'hi'),
              new TrainingDocument('hi', 'hello')
              
              ], function() {});

var howAction = function(context, request, response, next) {
    response.message = new SingleLineMessage('I\'m doing well. Thanks for asking.');
    next();
}; 

var whoAction = function(context, request, response, next) {
    response.message = new SingleLineMessage('I\'m Talkify bot for now.');
    next();
};
 
var helpAction = function(context, request, response, next) {
    response.message = new SingleLineMessage('Sure. What can I help you with?');
    next();
};

var hiAction = function(context, request, response, next) {
    response.message = new SingleLineMessage('Hello');
    next();
};

var undefAction = function(context, request, response, next) {
    response.message = new SingleLineMessage('Sorry I cannot understand what you typed');
    next();
};

var howSkill = new Skill('how_skill', 'how_are_you', howAction);
var whoSkill = new Skill('who_skill', 'who_are_you', whoAction);
var helpSkill = new Skill('help_skill', 'help', helpAction);
var hiSkill = new Skill('hi_skill','hi', hiAction);
var skill = new Skill('undefined',undefined,undefAction);

bot.addSkill(helpSkill);
bot.addSkill(hiSkill);
bot.addSkill(howSkill);
bot.addSkill(whoSkill);
bot.addSkill(skill);

module.exports = {
		
		processMsg: function(usrMsg, Msg){			
			var resp;			
			var resolved = function(err, messages) {
			    if(err){ 
			    	return console.error(err); 
			    }
			    console.log(usrMsg);
			    console.log(messages);
			    console.log(bot.getContextStore);
			    resp = messages;
			}			
			bot.resolve(125, usrMsg, resolved);
			return resp;			
		}            						
}
